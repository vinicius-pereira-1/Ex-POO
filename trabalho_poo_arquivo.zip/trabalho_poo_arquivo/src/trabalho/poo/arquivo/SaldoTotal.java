package trabalho.poo.arquivo;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.stream.IntStream;

public class SaldoTotal {

    public static void main(String[] args) throws IOException {

        Scanner leitor = new Scanner(System.in);

        try {
            Files.createDirectories(Paths.get("saldo-total"));
        } catch (IOException e) {
            e.printStackTrace();
        }

        System.out.print("Informe o seu salário do mês: R$");

        try {
            List salario = new ArrayList();
            salario.add(leitor.nextLine());

            Files.write(Paths.get("saldo-total/ganhos.txt"), salario, StandardCharsets.UTF_8, StandardOpenOption.APPEND);

            System.out.println("==============");
            System.out.println("O seu ganho no mês foi de: R$"+salario);
            System.out.println("==============");

        } catch (IOException e) {
            e.printStackTrace();
        }

        System.out.print("Informe quantas despesas teve no mês: ");

        int n = leitor.nextInt();

        System.out.println("Informe o valor das despesas: ");

        try {
            List despesas = new ArrayList();
            for (int i = 0; i <= n; i++) {
                despesas.add(leitor.nextLine());
            }
            Files.write(Paths.get("saldo-total/despesas.txt"), despesas, StandardCharsets.UTF_8, StandardOpenOption.APPEND);

            despesas.remove(0);
            System.out.println("==============");
            System.out.println();
            System.out.println("Suas despesas foram: "+despesas);
            System.out.println();
            System.out.println("==============");
            System.out.println();

        } catch (IOException e) {
            e.printStackTrace();
        }
        /*try {
            List entrou  = Files.readAllLines(Paths.get("saldo-total/ganhos.txt"));
            for(Object e: entrou){
                System.out.println("Ganho: R$"+e);
                System.out.println("==============");

            }
            List saiu = Files.readAllLines(Paths.get("saldo-total/despesas.txt"));
            for(Object s: saiu){
                //System.out.println("Despesa: R$"+s);
            }
            saiu.remove(0);
            System.out.println("Despesa: R$"+saiu);
        } catch (IOException e) {
            e.printStackTrace();
        }*/
    }
}

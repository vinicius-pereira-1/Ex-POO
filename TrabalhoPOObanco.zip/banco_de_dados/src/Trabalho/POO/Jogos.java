package Trabalho.POO;

public class Jogos {
    private int id;
    private String jogos;

    public Jogos(){}

    public Jogos(int id, String jogos){
        this.id = id;
        this.jogos = jogos;
    }

    public int getId(){
        return id;
    }

    public void setId(int id){
        this.id = id;
    }

    public String getJogos(){
        return jogos;
    }

    public void setJogos(String jogos){
        this.jogos = jogos;
    }

    @Override
    public String toString() {
        return "Jogos{" +
                "id=" + id +
                ", jogos='" + jogos + '\'' +
                '}';
    }
}
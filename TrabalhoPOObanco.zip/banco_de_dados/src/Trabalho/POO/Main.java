package Trabalho.POO;

public class Main {
    public static void main(String[] args){

        JogosDAO exe = new JogosDAO();

        for(Jogos p : exe.select()){
            System.out.println(p);
        }

        //Jogos novoJogo = new Jogos(0, "Tiro");
        //exe.add(novoJogo);

        //Jogos attJogo = new Jogos(5, "Plataforma");
        //exe.att(attJogo);

        //Jogos delJogo = new Jogos(1,"Corrida");
        //exe.del(delJogo);

    }
}
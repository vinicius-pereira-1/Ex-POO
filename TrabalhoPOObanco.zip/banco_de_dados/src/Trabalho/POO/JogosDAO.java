package Trabalho.POO;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class JogosDAO {

    public void add(Jogos jogos){
        String script = "insert into trabalho (JOGOS) values(?)";
        try(PreparedStatement stat = Conexao.getInstance().getConnection().prepareStatement(script)){
            stat.setString(1, jogos.getJogos());

            stat.execute();
        }catch (SQLException e){
            e.printStackTrace();
        }
    }

    public void att(Jogos jogos){
        String script = "update trabalho set JOGOS = ?";
        try(PreparedStatement stat = Conexao.getInstance().getConnection().prepareStatement(script)){
            stat.setString(1, jogos.getJogos());
            stat.setInt(2, jogos.getId());

            stat.execute();
        }catch (SQLException e){
            e.printStackTrace();
        }
    }

    public void del(Jogos jogos){
        String script = "delete from trabalho where ID = ?";
        try(PreparedStatement stat = Conexao.getInstance().getConnection().prepareStatement(script)){
            stat.setInt(1, jogos.getId());


            stat.execute();
        }catch (SQLException e){
            e.printStackTrace();
        }
    }

    public List<Jogos> select(){
        String script = "select ID, JOGOS from trabalho order by JOGOS";
        List<Jogos> lista = new ArrayList<>();
        try(PreparedStatement stat = Conexao.getInstance().getConnection().prepareStatement(script)){
            ResultSet resultSet = stat.executeQuery();

            while(resultSet.next()){
                Jogos jogo = new Jogos();
                jogo.setId(resultSet.getInt(1));
                jogo.setJogos(resultSet.getString(2));
                lista.add(jogo);
            }
            resultSet.close();
        }catch (SQLException e){
            e.printStackTrace();
        }
        return lista;
    }

}
package br.univille.poo.swing;

public class Main {

    public static void main(String[] args) {
        TelaLogin janela = new TelaLogin();
        janela.setVisible(true);
    }

}

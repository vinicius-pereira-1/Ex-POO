package app.entidade;

public class Pessoa {

    private int id;
    private String Nome;
    private String Sobrenome;

    public int getId(){
        return id;
    };

    public void setId(int id){
        this.id = id;
    };

    public String getNome(){
        return Nome;
    };

    public void setNome(String nome){
        Nome = nome;
    };

    public String getSobrenome(){
        return Sobrenome;
    };

    public void setSobrenome(String sobrenome){
        Sobrenome = sobrenome;
    };

    public String toString() {
        return "Nome: " + getNome() + " | Sobrenome: " + getSobrenome() + " | Id :" + getId();
    }

}

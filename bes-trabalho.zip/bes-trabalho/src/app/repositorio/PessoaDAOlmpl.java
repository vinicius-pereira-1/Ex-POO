package app.repositorio;

import app.entidade.Pessoa;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class PessoaDAOlmpl implements PessoaDAO{

    private Map<Integer, Pessoa> dados = new HashMap<>();

    private int identificador = 1;

    @Override
    public int adicionar(Pessoa p) {
        dados.put(identificador, p);
        System.out.println(p);
        identificador ++;
        return identificador;
    }

    @Override
    public void atualizar(Pessoa p) {
        dados.replace(p.getId(), p);
    }

    @Override
    public void deletarPeloId(int id) {
        System.out.println("Pessoa " +id+ " deletada");
        id = identificador;
        dados.remove(id);
    }

    @Override
    public Pessoa obterPeloId(int id) {
        System.out.println("Pessoa obtida");
        Pessoa nome;
        nome = dados.get(id);
        System.out.println(nome);
        return nome;
    }

    @Override
    public List<Pessoa> obterTodos() {
        ArrayList<Pessoa> lista = new ArrayList<>(dados.values());
        return lista;
    }

}

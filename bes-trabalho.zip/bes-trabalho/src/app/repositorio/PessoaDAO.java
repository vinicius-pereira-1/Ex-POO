package app.repositorio;

import app.entidade.Pessoa;
import java.util.ArrayList;
import java.util.List;

public interface PessoaDAO {

    int adicionar(Pessoa p);

    void atualizar(Pessoa p);

    void deletarPeloId(int id);

    public Pessoa obterPeloId(int id);

    public List<Pessoa> obterTodos();
}

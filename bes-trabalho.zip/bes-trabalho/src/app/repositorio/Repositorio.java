package app.repositorio;

import app.entidade.Pessoa;

public class Repositorio {

    private static Repositorio instancia;
    private static PessoaDAOlmpl PessoaDAO;

    public static Repositorio obterInstancia() {
        if(instancia == null){
            instancia = new Repositorio();
        }
        return instancia;
    }

    public static PessoaDAO pessoas() {
        PessoaDAO = new PessoaDAOlmpl();
        return PessoaDAO;
    }

    private Repositorio(){

    }
}

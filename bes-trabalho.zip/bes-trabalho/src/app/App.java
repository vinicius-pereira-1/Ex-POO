package app;

import app.entidade.Pessoa;
import app.repositorio.PessoaDAO;
import app.repositorio.Repositorio;

public class App {

    public static void main(String[] Args){
        App app = new App();
        app.executar();
    }

    public void executar() {
        PessoaDAO d = Repositorio.pessoas();
        Pessoa pessoa1 = new Pessoa();
        Pessoa pessoa2 = new Pessoa();
        Pessoa pessoa3 = new Pessoa();
        Pessoa pessoa4 = new Pessoa();

        System.out.println("ADICIONAR");

        pessoa1.setNome("Rafael");
        pessoa1.setSobrenome("Bastos");
        pessoa1.setId(1);

        pessoa2.setNome("Mauricio");
        pessoa2.setSobrenome("Matar");
        pessoa2.setId(2);

        pessoa3.setNome("Jorge");
        pessoa3.setSobrenome("Ribamar");
        pessoa3.setId(3);

        pessoa4.setNome("Will");
        pessoa4.setSobrenome("Smith");
        pessoa4.setId(4);

        d.adicionar(pessoa1);
        d.adicionar(pessoa2);
        d.adicionar(pessoa3);
        d.adicionar(pessoa4);

        pessoa1.setNome("Jorge");
        pessoa1.setSobrenome("Rafael");
        pessoa1.setId(1);

        d.atualizar(pessoa1);
        System.out.println("Pessoa "+ pessoa1.getId()+ " atualizada\n");

        d.obterPeloId(2);
        d.deletarPeloId(4);
        System.out.println("Todos da lista: "+ d.obterTodos());
    }

}

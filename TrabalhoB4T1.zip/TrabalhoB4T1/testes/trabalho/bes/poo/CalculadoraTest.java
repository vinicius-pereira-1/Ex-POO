package trabalho.bes.poo;

import org.junit.jupiter.api.Test;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class CalculadoraTest {

    Set<Integer> setA = new HashSet<>(List.of(3, 4));
    Set<Integer> setB = new HashSet<>(List.of(1, 2));
    Set<Integer> setC = new HashSet<>(List.of(1, 2, 3, 4));

    @Test
    public void testarUniao(){
        Calculadora c = new Calculadora();
        Set<Integer> resultadoObtido = c.uniao(setA, setB);
        Set<Integer> resultadoEsperado = setC;
        assertEquals(resultadoEsperado, resultadoObtido);
    }

}

package trabalho.bes.poo;

import java.util.*;

public class Calculadora {

    public Set<Integer> uniao (Set<Integer> setA, Set<Integer> setB){

        setA.addAll(setB);

        return setA;
    }

}

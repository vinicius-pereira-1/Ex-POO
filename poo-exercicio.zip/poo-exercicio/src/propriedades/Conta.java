package propriedades;

public abstract class Conta {

    private Integer num;
    private String dono;
    protected Double sal;

    public Conta() {
    }

    public Conta(Integer num, String dono, Double saldo) {
        this.num = num;
        this.dono = dono;
        this.sal = sal;
    }

    public Integer getNum() {
        return num;
    }

    public void setNum(Integer num) {
        this.num = num;
    }

    public String getDono() {
        return dono;
    }

    public void setDono(String dono) {
        this.dono = dono;
    }

    public Double getSaldo() {
        return sal;
    }

    public void saque(double quantidade) {
        sal -= quantidade + 5.0;
    }

    public void deposito(double quantidade) {
        sal += quantidade;
    }
}

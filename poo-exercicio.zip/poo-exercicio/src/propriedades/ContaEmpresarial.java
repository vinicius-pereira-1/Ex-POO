package propriedades;

public class ContaEmpresarial extends Conta {

    private Double limiteEmprestimo;

    public ContaEmpresarial() {
        super();
    }

    public ContaEmpresarial(Integer num, String dono, Double sal, Double limiteEmprestimo) {
        super(num, dono, sal);
        this.limiteEmprestimo = limiteEmprestimo;
    }

    public Double getLimiteEmprestimo() {
        return limiteEmprestimo;
    }

    public void setLimiteEmprestimo(Double loanLimit) {
        this.limiteEmprestimo = limiteEmprestimo;
    }

    public void loan(double quantia) {
        if (quantia <= limiteEmprestimo) {
            sal += quantia - 10.0;
        }
    }

    @Override
    public void saque(double quantidade) {
        super.saque(quantidade);
        sal -= 2.0;
    }
}

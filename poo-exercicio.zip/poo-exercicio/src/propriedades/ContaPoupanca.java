package propriedades;

public class ContaPoupanca extends Conta {

    private Double taxJuro;

    public ContaPoupanca() {
        super();
    }

    public ContaPoupanca(Integer num, String dono, Double sal, Double taxJuro) {
        super(num, dono, sal);
        this.taxJuro = taxJuro;
    }

    public Double getTaxJuro() {
        return taxJuro;
    }

    public void setTaxaJuro(Double taxJuro) {
        this.taxJuro = taxJuro;
    }

    public void atualizacaoSaldo() {
        sal += sal * taxJuro;
    }

    @Override
    public final void saque(double quantidade) {
        sal -= quantidade;
    }
}

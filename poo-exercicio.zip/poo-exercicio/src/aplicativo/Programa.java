package aplicativo;

import java.util.ArrayList;
import java.util.List;

import propriedades.Conta;
import propriedades.ContaEmpresarial;
import propriedades.ContaPoupanca;

public class Programa {

    public static void main(String[] args) {

        List<Conta> lista = new ArrayList<>();

        lista.add(new ContaPoupanca(01, "Marcela", 500.00, 0.01));
        lista.add(new ContaEmpresarial(02, "Roberto", 1000.0, 400.0));
        lista.add(new ContaPoupanca(03, "Jorge", 300.0, 0.01));
        lista.add(new ContaEmpresarial(04, "Lucas", 500.0, 500.0));

        double soma = 0.0;
        for (Conta acc : lista) {
            soma += acc.getSaldo();
        }

        System.out.printf("Total de saldo: %.2f%n", soma);
        System.out.println();

        for (Conta acc : lista) {
            acc.deposito(10.0);
        }
        for (Conta acc : lista) {
            System.out.printf("Saldo atual da conta %d: R$ %.2f%n", acc.getNum(), acc.getSaldo());
        }
    }
}
